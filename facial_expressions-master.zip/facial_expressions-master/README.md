# facial_expressions
this library contains code for arduino for complete tag of facial expressions compatible with MAX72 LED driver dot matrix
